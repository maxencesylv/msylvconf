import json

employee = {
	"nom": "Marie Richardson",
	"id": 1,
	"recrutement": True,
	"department": "Ventes"
}

with open('data.json', 'w') as mon_fichier:
	json.dump(employee, mon_fichier)
