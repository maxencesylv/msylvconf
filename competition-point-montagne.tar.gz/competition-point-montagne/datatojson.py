import json
def appendJson(new_data, filename='mountainclimbing/src/data.json'):
    with open(filename,'r+') as file:
        file_data = json.load(file)
        for user in file_data["usersGrade"]:
            if user["username"] == new_data["username"]:
                file_data["usersGrade"].remove(user)
                file_data["usersGrade"].append(new_data)
                file.seek(0)
                json.dump(file_data, file, indent = 4)
                return
        file_data["usersGrade"].append(new_data)
        file.seek(0)
        json.dump(file_data, file, indent = 4)
        return