import mysql.connector
db = mysql.connector.connect(
    host="109.234.162.62",
    user="wddg8033_mountainmanager",
    password="8xX8DEr@L3zMD@!zyxtEpac&BizsD$J9DeR",
    database="wddg8033_mountainclimbing"
)
def dataRecovery(specter):
    if specter == "limited":
        cursor = db.cursor()
        cursor.execute("""SELECT username, urlwebsite, name FROM websession""")
        dbData = cursor.fetchall()
    elif specter == "middle":
        cursor = db.cursor()
        cursor.execute("""SELECT name, username, urlwebsite, grade FROM websession""")
        dbData = cursor.fetchall()
    elif specter == "full":
        cursor = db.cursor()
        cursor.execute("""SELECT * FROM websession""")
        dbData = cursor.fetchall()
    else:
        dbData = "Error: dataRecovery -> Specter not found."
    return dbData
