import requests
import db
from datatojson import appendJson
from bs4 import BeautifulSoup
x = 1
while x == 1:
    for user in db.dataRecovery("limited"):
        urlDOM = user[1]
        urlCSS = user[1] + "/style.css"
        css = requests.get(urlCSS)
        dom = requests.get(urlDOM)
        cssParsed = BeautifulSoup(css.content, 'html.parser')
        cssWordsList = cssParsed.text.split()
        domParsed = BeautifulSoup(dom.content, 'html.parser')
        htmlComponents=["h1","h2","h3","h4","h5","h6","p","li","button","input","img","div","span","script","table","tr","td","th","caption","thead","tbody","tfoot","form","label","select","option","header","footer","nav","article","section","aside","i","ul","ol","a","dl","dt","abbr","blockquote","cite","sub","sup","mark","strong","em","figure","audio","video","source","canvas","br","hr","figcaption","progress","time","link","meta","style"]
        htmlComponentsGrade = {"h1": 3, "h2": 2, "h3": 1, "h4": 1, "h5": 1, "h6": 1, "p": 3, "li": 3, "button": 2, "input": 3, "img": 4, "div": 3, "span": 2, "script": 1, "table": 4, "tr": 1, "td": 1, "th": 1, "caption": 1, "thead": 1, "tbody": 1, "tfoot": 1, "form": 2, "label": 2, "select": 1, "option": 1, "header": 3, "footer": 3, "nav": 1, "article": 1, "section": 2, "aside": 1, "i": 1, "ul": 1, "ol": 1, "a": 3, "dl": 1, "dt": 1, "abbr": 1, "blockquote": 1, "cite": 1, "sub": 1, "sup": 1, "mark": 1, "strong": 2, "em": 1, "figure": 1, "audio": 2, "video": 3, "source": 1, "canvas": 1, "br": 1, "hr": 1, "figcaption": 1, "progress": 1, "time": 1, "link": 1, "meta": 5, "style": 2 }
        cssComponents=["color:", "background-color:", "font-size:", "font-family:", "font-weight:", "letter-spacing:", "display:", "margin:", "padding:", "width:", "height:", "text-transform:"]
        cssComponentsGrade = {"color:": 1, "background-color:": 1, "font-size:": 1, "font-family:": 1, "font-weight:": 1, "letter-spacing:": 1, "display:": 1, "margin:": 1, "padding:": 1, "width:": 1, "height:": 1, "text-transform:": 2}
        def calcGradeMax():
            gradeMax = 0
            for component in htmlComponents:
                gradeMax += htmlComponentsGrade[component]
            for component in cssComponents:
                gradeMax += cssComponentsGrade[component]
            return gradeMax
        points = 0
        for el in htmlComponents:
            if len(domParsed.find_all(el)) > 0:
                points += htmlComponentsGrade[el]
        for el in cssWordsList:
            if el in cssComponents:
                points += cssComponentsGrade[el]
        userresult = {
            "username": user[0],
            "percentgrade": round(points/calcGradeMax()*100, 0)
        }
        appendJson(userresult)
        print(user[0] + " / "+ user[2] + " - ", points, "/", calcGradeMax(), '|', round(points/calcGradeMax()*100, 1), "%")
